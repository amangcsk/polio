import { EducationExperience } from '../EducationExperience';

export default function EducationExperienceExample() {
  return <EducationExperience />;
}