import { LearningResources } from '../LearningResources';

export default function LearningResourcesExample() {
  return <LearningResources />;
}