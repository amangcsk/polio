import { BlogPostList } from '../BlogPostList';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: false,
    },
  },
});

export default function BlogPostListExample() {
  return (
    <QueryClientProvider client={queryClient}>
      <BlogPostList />
    </QueryClientProvider>
  );
}